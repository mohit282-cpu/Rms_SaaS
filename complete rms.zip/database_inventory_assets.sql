-- QR Cafe POS - Enterprise Inventory & Asset Management System Migration Schema
-- Execute this script on MySQL / MariaDB to ensure all required tables, columns, and seed data exist.

USE qr_restaurant;

-- 1. Inventory Categories
CREATE TABLE IF NOT EXISTS inventory_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT '',
    icon VARCHAR(50) DEFAULT '📦',
    display_order INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO inventory_categories (name, icon, display_order) VALUES
    ('Vegetables','🥬',1),
    ('Meat','🥩',2),
    ('Seafood','🦐',3),
    ('Dairy','🧀',4),
    ('Frozen','🧊',5),
    ('Dry Goods','🌾',6),
    ('Bakery','🍞',7),
    ('Beverages','🥤',8),
    ('Packaging','📦',9),
    ('Cleaning','🧹',10),
    ('Spices','🌶️',11),
    ('Other','📋',12);

-- 2. Inventory Measurement Units
CREATE TABLE IF NOT EXISTS inventory_units (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    abbreviation VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO inventory_units (name, abbreviation) VALUES
    ('Kilogram','kg'),
    ('Gram','g'),
    ('Liter','L'),
    ('Milliliter','mL'),
    ('Piece','pcs'),
    ('Dozen','dz'),
    ('Box','box'),
    ('Packet','pkt'),
    ('Bottle','btl'),
    ('Can','can'),
    ('Bag','bag'),
    ('Carton','ctn');

-- 3. Suppliers Profile
CREATE TABLE IF NOT EXISTS suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(150) DEFAULT '',
    phone VARCHAR(30) DEFAULT '',
    email VARCHAR(150) DEFAULT '',
    address TEXT,
    vat_pan VARCHAR(50) DEFAULT '',
    outstanding_balance DECIMAL(12,2) DEFAULT 0.00,
    performance_rating DECIMAL(3,1) DEFAULT 5.0,
    status ENUM('active','inactive','blacklisted') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_supplier_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Inventory Stock Items
CREATE TABLE IF NOT EXISTS inventory_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    barcode VARCHAR(100) DEFAULT '',
    qr_token VARCHAR(64) DEFAULT '',
    name VARCHAR(200) NOT NULL,
    category_id INT DEFAULT NULL,
    brand VARCHAR(100) DEFAULT '',
    supplier_id INT DEFAULT NULL,
    unit_id INT DEFAULT NULL,
    current_stock DECIMAL(12,3) DEFAULT 0.000,
    minimum_stock DECIMAL(12,3) DEFAULT 0.000,
    maximum_stock DECIMAL(12,3) DEFAULT 0.000,
    purchase_cost DECIMAL(12,2) DEFAULT 0.00,
    average_cost DECIMAL(12,2) DEFAULT 0.00,
    storage_location VARCHAR(100) DEFAULT '',
    batch_number VARCHAR(100) DEFAULT '',
    expiry_date DATE DEFAULT NULL,
    status ENUM('active','inactive','discontinued') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_inv_category (category_id),
    INDEX idx_inv_supplier (supplier_id),
    INDEX idx_inv_stock (current_stock, minimum_stock),
    INDEX idx_inv_expiry (expiry_date),
    INDEX idx_inv_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Purchase Orders
CREATE TABLE IF NOT EXISTS purchase_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_number VARCHAR(50) NOT NULL UNIQUE,
    supplier_id INT NOT NULL,
    status ENUM('draft','approved','ordered','partial','received','cancelled','payment_pending','completed') DEFAULT 'draft',
    subtotal DECIMAL(12,2) DEFAULT 0.00,
    tax_amount DECIMAL(12,2) DEFAULT 0.00,
    discount_amount DECIMAL(12,2) DEFAULT 0.00,
    total_amount DECIMAL(12,2) DEFAULT 0.00,
    invoice_number VARCHAR(100) DEFAULT '',
    attachments TEXT,
    notes TEXT,
    created_by VARCHAR(100) DEFAULT 'admin',
    approved_by VARCHAR(100) DEFAULT '',
    order_date DATE DEFAULT NULL,
    expected_date DATE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_po_supplier (supplier_id),
    INDEX idx_po_status (status),
    INDEX idx_po_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Purchase Order Items
CREATE TABLE IF NOT EXISTS purchase_order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_id INT NOT NULL,
    inventory_item_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    total_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    received_qty DECIMAL(12,3) DEFAULT 0.000,
    rejected_qty DECIMAL(12,3) DEFAULT 0.000,
    INDEX idx_poi_po (po_id),
    INDEX idx_poi_item (inventory_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Goods Receipts
CREATE TABLE IF NOT EXISTS goods_receipts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_id INT DEFAULT NULL,
    supplier_id INT DEFAULT NULL,
    inventory_item_id INT NOT NULL,
    received_qty DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    rejected_qty DECIMAL(12,3) DEFAULT 0.000,
    damaged_qty DECIMAL(12,3) DEFAULT 0.000,
    unit_cost DECIMAL(12,2) DEFAULT 0.00,
    batch_number VARCHAR(100) DEFAULT '',
    expiry_date DATE DEFAULT NULL,
    invoice_number VARCHAR(100) DEFAULT '',
    received_by VARCHAR(100) DEFAULT 'admin',
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    INDEX idx_gr_po (po_id),
    INDEX idx_gr_item (inventory_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Inventory Transactions (Immutable Audit Log)
CREATE TABLE IF NOT EXISTS inventory_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT NOT NULL,
    type ENUM('purchase','consumption','waste','adjustment','transfer','return','damage','manual') NOT NULL,
    quantity DECIMAL(12,3) NOT NULL,
    direction ENUM('in','out') NOT NULL,
    reference_type VARCHAR(50) DEFAULT '',
    reference_id INT DEFAULT NULL,
    stock_before DECIMAL(12,3) DEFAULT 0.000,
    stock_after DECIMAL(12,3) DEFAULT 0.000,
    unit_cost DECIMAL(12,2) DEFAULT 0.00,
    notes TEXT,
    created_by VARCHAR(100) DEFAULT 'system',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_it_item (inventory_item_id),
    INDEX idx_it_type (type),
    INDEX idx_it_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. Recipes (Bill of Materials)
CREATE TABLE IF NOT EXISTS recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    menu_item_id INT NOT NULL,
    name VARCHAR(200) DEFAULT '',
    yield_qty DECIMAL(10,2) DEFAULT 1.00,
    notes TEXT,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_recipe_menu (menu_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. Recipe Items (Ingredients per Recipe)
CREATE TABLE IF NOT EXISTS recipe_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id INT NOT NULL,
    inventory_item_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    unit_id INT DEFAULT NULL,
    notes VARCHAR(255) DEFAULT '',
    INDEX idx_ri_recipe (recipe_id),
    INDEX idx_ri_item (inventory_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. Inventory Waste Tracking
CREATE TABLE IF NOT EXISTS inventory_waste (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL,
    reason ENUM('kitchen_waste','expired','customer_return','damaged','spoilage','other') DEFAULT 'kitchen_waste',
    unit_cost DECIMAL(12,2) DEFAULT 0.00,
    total_cost DECIMAL(12,2) DEFAULT 0.00,
    reported_by VARCHAR(100) DEFAULT 'admin',
    approved_by VARCHAR(100) DEFAULT '',
    approval_status ENUM('pending','approved','rejected') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_waste_item (inventory_item_id),
    INDEX idx_waste_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. Stock Physical Audits
CREATE TABLE IF NOT EXISTS stock_audits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT NOT NULL,
    system_qty DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    physical_qty DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    variance DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    adjustment_made TINYINT(1) DEFAULT 0,
    audited_by VARCHAR(100) DEFAULT 'admin',
    approved_by VARCHAR(100) DEFAULT '',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_item (inventory_item_id),
    INDEX idx_audit_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. Inventory Low-Stock & Expiry Alerts
CREATE TABLE IF NOT EXISTS inventory_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT NOT NULL,
    alert_type ENUM('low_stock','out_of_stock','near_expiry','expired','overstock') NOT NULL,
    message VARCHAR(500) DEFAULT '',
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_alert_item (inventory_item_id),
    INDEX idx_alert_type (alert_type),
    INDEX idx_alert_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. Asset Categories
CREATE TABLE IF NOT EXISTS asset_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT '',
    icon VARCHAR(50) DEFAULT '🏗️',
    depreciation_method ENUM('straight_line','declining_balance','none') DEFAULT 'straight_line',
    depreciation_rate DECIMAL(5,2) DEFAULT 0.00,
    default_useful_life INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO asset_categories (name, icon, default_useful_life) VALUES
    ('Kitchen Equipment','🍳',120),
    ('Furniture','🪑',120),
    ('Electronics','💻',60),
    ('Vehicles','🚗',120),
    ('Building','🏢',360),
    ('Utensils','🍴',36),
    ('HVAC Systems','❄️',120),
    ('POS Hardware','🖥️',60),
    ('Other','📋',60);

-- 15. Asset Register
CREATE TABLE IF NOT EXISTS assets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_code VARCHAR(50) NOT NULL UNIQUE,
    qr_token VARCHAR(64) DEFAULT '',
    barcode VARCHAR(100) DEFAULT '',
    name VARCHAR(200) NOT NULL,
    category_id INT DEFAULT NULL,
    brand VARCHAR(100) DEFAULT '',
    model VARCHAR(100) DEFAULT '',
    serial_number VARCHAR(100) DEFAULT '',
    purchase_date DATE DEFAULT NULL,
    purchase_cost DECIMAL(12,2) DEFAULT 0.00,
    supplier_id INT DEFAULT NULL,
    warranty_expiry DATE DEFAULT NULL,
    assigned_branch VARCHAR(100) DEFAULT 'Main Branch',
    assigned_location VARCHAR(100) DEFAULT '',
    assigned_employee VARCHAR(100) DEFAULT '',
    `condition` ENUM('excellent','good','fair','poor','damaged') DEFAULT 'good',
    status ENUM('available','in_use','maintenance','repair','retired','disposed','lost') DEFAULT 'available',
    useful_life_months INT DEFAULT 60,
    residual_value DECIMAL(12,2) DEFAULT 0.00,
    current_value DECIMAL(12,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_asset_category (category_id),
    INDEX idx_asset_status (status),
    INDEX idx_asset_qr (qr_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. Asset Maintenance Schedule & Logs
CREATE TABLE IF NOT EXISTS asset_maintenance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    type ENUM('preventive','corrective','emergency') DEFAULT 'preventive',
    description TEXT,
    technician VARCHAR(150) DEFAULT '',
    cost DECIMAL(12,2) DEFAULT 0.00,
    parts_used TEXT,
    service_date DATE NOT NULL,
    next_service_date DATE DEFAULT NULL,
    status ENUM('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_maint_asset (asset_id),
    INDEX idx_maint_date (service_date),
    INDEX idx_maint_next (next_service_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. Asset Warranty Claims & Tracking
CREATE TABLE IF NOT EXISTS asset_warranties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    provider_name VARCHAR(150) DEFAULT '',
    policy_number VARCHAR(100) DEFAULT '',
    start_date DATE DEFAULT NULL,
    expiry_date DATE NOT NULL,
    coverage_details TEXT,
    claim_status ENUM('active','claim_pending','repaired','replaced','expired') DEFAULT 'active',
    claim_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_warr_asset (asset_id),
    INDEX idx_warr_expiry (expiry_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. Asset Transfers Log
CREATE TABLE IF NOT EXISTS asset_transfers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    from_location VARCHAR(100) DEFAULT '',
    to_location VARCHAR(100) DEFAULT '',
    from_employee VARCHAR(100) DEFAULT '',
    to_employee VARCHAR(100) DEFAULT '',
    transfer_date DATE NOT NULL,
    reason TEXT,
    transferred_by VARCHAR(100) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_asset (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 19. Asset Depreciation Engine Log
CREATE TABLE IF NOT EXISTS asset_depreciation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    period_date DATE NOT NULL,
    method ENUM('straight_line','declining_balance') DEFAULT 'straight_line',
    depreciation_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    accumulated_depreciation DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    book_value DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_dep_asset (asset_id),
    INDEX idx_dep_period (period_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 20. Immutable Asset Audit Trail
CREATE TABLE IF NOT EXISTS asset_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    description TEXT,
    changed_by VARCHAR(100) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_al_asset (asset_id),
    INDEX idx_al_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
