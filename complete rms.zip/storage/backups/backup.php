<?php
// storage/backups/backup.php - Database Backup & Export Script
require_once __DIR__ . '/../../config.php';

use App\Services\LoggerService;

if (php_sapi_name() !== 'cli' && !Auth::isAdminLoggedIn()) {
    Response::error('Unauthorized access. Admin privileges required.', 401);
}

$host = getenv('DB_HOST') ?: 'localhost';
$user = getenv('DB_USERNAME') ?: 'root';
$pass = getenv('DB_PASSWORD') ?: '';
$name = getenv('DB_DATABASE') ?: 'qr_restaurant';

$backupDir = __DIR__;
$backupFile = $backupDir . '/backup_' . $name . '_' . date('Y-m-d_H-i-s') . '.sql';

try {
    $pdo = App\Services\DatabaseService::getInstance()->getPdo();
    $tables = [];
    $stmt = $pdo->query("SHOW TABLES");
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        $tables[] = $row[0];
    }

    $sqlDump = "-- QR Cafe Database Backup" . PHP_EOL;
    $sqlDump .= "-- Generated: " . date('Y-m-d H:i:s') . PHP_EOL . PHP_EOL;
    $sqlDump .= "SET FOREIGN_KEY_CHECKS=0;" . PHP_EOL . PHP_EOL;

    foreach ($tables as $table) {
        $createStmt = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
        $sqlDump .= "DROP TABLE IF EXISTS `$table`;" . PHP_EOL;
        $sqlDump .= $createStmt['Create Table'] . ";" . PHP_EOL . PHP_EOL;

        $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $cols = array_map(function($c) { return "`$c`"; }, array_keys($row));
            $vals = array_map(function($v) use ($pdo) {
                return $v === null ? "NULL" : $pdo->quote($v);
            }, array_values($row));

            $sqlDump .= "INSERT INTO `$table` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");" . PHP_EOL;
        }
        $sqlDump .= PHP_EOL;
    }

    $sqlDump .= "SET FOREIGN_KEY_CHECKS=1;" . PHP_EOL;

    file_put_contents($backupFile, $sqlDump);
    LoggerService::security("Database backup created successfully: " . basename($backupFile));

    if (php_sapi_name() === 'cli') {
        echo "✅ Backup successfully saved to: " . $backupFile . PHP_EOL;
    } else {
        Response::success('Database backup generated successfully', ['file' => basename($backupFile)]);
    }

} catch (Exception $e) {
    LoggerService::error("Database backup failed: " . $e->getMessage());
    if (php_sapi_name() === 'cli') {
        echo "❌ Backup error: " . $e->getMessage() . PHP_EOL;
    } else {
        Response::error('Failed to generate backup: ' . $e->getMessage(), 500);
    }
}
