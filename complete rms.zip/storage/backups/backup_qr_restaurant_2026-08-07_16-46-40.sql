-- QR Cafe Database Backup
-- Generated: 2026-08-07 16:46:40

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_users` (`id`, `username`, `password`, `full_name`, `created_at`) VALUES ('1', 'admin', '$2y$10$u1UufRNG76.FefDnIIRgPufXhuB7yaWUVvHcZWiIbnr.aMaNUCKbu', 'Administrator', '2026-07-23 19:40:26');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES ('1', 'Main Dishes', 'Delicious entrees', '2026-07-23 19:43:19');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES ('2', 'Beverages', 'Refreshing drinks', '2026-07-23 19:43:19');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES ('3', 'Desserts', 'Sweet treats', '2026-07-23 19:43:19');

DROP TABLE IF EXISTS `landing_page_settings`;
CREATE TABLE `landing_page_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) DEFAULT 'QR Cafe & Dining',
  `brand_logo` varchar(255) DEFAULT '☕',
  `brand_logo_image` varchar(255) DEFAULT '',
  `hero_badge` varchar(255) DEFAULT '⭐ Gourmet Culinary Experience',
  `hero_title` varchar(255) DEFAULT 'Artisanal Flavors & Modern Dining',
  `hero_subtitle` text DEFAULT NULL,
  `hero_cta_primary` varchar(255) DEFAULT '?️ View Signature Menu',
  `hero_cta_secondary` varchar(255) DEFAULT '? Location & Hours',
  `qr_notice_text` varchar(500) DEFAULT 'Dining in? Scan the QR code on your table for live ordering & waiter service!',
  `about_badge` varchar(255) DEFAULT 'About Us',
  `about_title` varchar(255) DEFAULT 'Our Culinary Journey',
  `about_text` text DEFAULT NULL,
  `about_feature1_title` varchar(255) DEFAULT '100%',
  `about_feature1_desc` varchar(255) DEFAULT 'Fresh & Organic',
  `about_feature2_title` varchar(255) DEFAULT 'Handcrafted',
  `about_feature2_desc` varchar(255) DEFAULT 'Specialty Coffee',
  `dishes_badge` varchar(255) DEFAULT 'Chef Recommended',
  `dishes_title` varchar(255) DEFAULT 'Signature Dishes & Brews',
  `dishes_subtitle` varchar(255) DEFAULT 'Explore our top culinary creations crafted daily with passion',
  `location_title` varchar(255) DEFAULT 'Location & Address',
  `location_address` varchar(255) DEFAULT 'Kathmandu, Nepal',
  `contact_phone` varchar(50) DEFAULT '+977 9800000000',
  `contact_email` varchar(100) DEFAULT 'info@qrcafe.com',
  `hours_title` varchar(255) DEFAULT 'Opening Hours',
  `opening_hours` varchar(255) DEFAULT 'Mon - Sun: 8:00 AM - 10:00 PM',
  `hero_image` varchar(255) DEFAULT '',
  `footer_copyright` varchar(255) DEFAULT '© 2026 QR Cafe & Dining. All rights reserved.',
  `kds_password` varchar(255) DEFAULT 'kitchen123',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `landing_page_settings` (`id`, `brand_name`, `brand_logo`, `brand_logo_image`, `hero_badge`, `hero_title`, `hero_subtitle`, `hero_cta_primary`, `hero_cta_secondary`, `qr_notice_text`, `about_badge`, `about_title`, `about_text`, `about_feature1_title`, `about_feature1_desc`, `about_feature2_title`, `about_feature2_desc`, `dishes_badge`, `dishes_title`, `dishes_subtitle`, `location_title`, `location_address`, `contact_phone`, `contact_email`, `hours_title`, `opening_hours`, `hero_image`, `footer_copyright`, `kds_password`, `updated_at`) VALUES ('1', 'QR Cafe &amp; Dining', '☕', '', '⭐ Gourmet Culinary Experience', 'Artisanal Flavors &amp; Modern Dining', 'Experience handcrafted gourmet meals, freshly brewed espresso, and seamless digital table ordering.', '🍽️ View Signature Menu', '📍 Location &amp; Hours', 'Dining in? Scan the QR code on your table for live ordering &amp; waiter service!', 'About Us', 'Our Culinary Journey', 'Welcome to QR Cafe, where passion meets culinary perfection. We serve artisanal dishes prepared with organic ingredients, handcrafted coffee, and gourmet desserts in a warm, modern atmosphere.', '100%', 'Fresh &amp; Organic', 'Handcrafted', 'Specialty Coffee', 'Chef Recommended', 'Signature Dishes &amp; Brews', 'Explore our top culinary creations crafted daily with passion', 'Location &amp; Address', 'Kathmandu, Nepal', '+977 9800000000', 'info@qrcafe.com', 'Opening Hours', 'Mon - Sun: 8:00 AM - 10:00 PM', '', '', 'kitchen123', '2026-07-25 12:18:58');

DROP TABLE IF EXISTS `menu_addons`;
CREATE TABLE `menu_addons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `menu_addons` (`id`, `name`, `price`, `status`, `created_at`) VALUES ('1', 'Extra Cheese', '50.00', 'active', '2026-07-25 12:18:28');
INSERT INTO `menu_addons` (`id`, `name`, `price`, `status`, `created_at`) VALUES ('2', 'Crispy Fries', '80.00', 'active', '2026-07-25 12:18:28');
INSERT INTO `menu_addons` (`id`, `name`, `price`, `status`, `created_at`) VALUES ('3', 'Extra Dip / Sauce', '30.00', 'active', '2026-07-25 12:18:28');

DROP TABLE IF EXISTS `menu_items`;
CREATE TABLE `menu_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `status` enum('active','sold_out','inactive') DEFAULT 'active',
  `is_popular` tinyint(1) DEFAULT 0,
  `preparation_time` int(11) DEFAULT 15,
  `dietary_type` enum('veg','non-veg') DEFAULT 'veg',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `addons` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `menu_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `menu_items` (`id`, `name`, `description`, `price`, `image`, `category_id`, `status`, `is_popular`, `preparation_time`, `dietary_type`, `created_at`, `addons`) VALUES ('1', 'momo', '', '100.00', 'icon-192.png', '1', 'active', '0', '15', 'veg', '2026-07-23 19:46:15', NULL);

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `menu_item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `menu_item_id` (`menu_item_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `order_items` (`id`, `order_id`, `menu_item_id`, `quantity`, `price`) VALUES ('1', '1', '1', '1', '100.00');
INSERT INTO `order_items` (`id`, `order_id`, `menu_item_id`, `quantity`, `price`) VALUES ('2', '2', '1', '1', '100.00');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_number` varchar(10) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('new','preparing','ready','completed','cancelled') DEFAULT 'new',
  `total_amount` decimal(10,2) DEFAULT 0.00,
  `payment_status` enum('pending','paid') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `orders` (`id`, `table_number`, `customer_name`, `notes`, `status`, `total_amount`, `payment_status`, `payment_method`, `created_at`, `updated_at`) VALUES ('1', '1', '', '', 'completed', '100.00', 'pending', 'pending', '2026-07-23 19:46:43', '2026-07-23 19:50:24');
INSERT INTO `orders` (`id`, `table_number`, `customer_name`, `notes`, `status`, `total_amount`, `payment_status`, `payment_method`, `created_at`, `updated_at`) VALUES ('2', '1', '', '', 'completed', '100.00', 'pending', 'pending', '2026-08-07 19:39:52', '2026-08-07 19:40:06');

DROP TABLE IF EXISTS `payment_settings`;
CREATE TABLE `payment_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_name` varchar(200) DEFAULT 'QR Restaurant',
  `payment_note` varchar(500) DEFAULT NULL,
  `qr_code_image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_settings` (`id`, `restaurant_name`, `payment_note`, `qr_code_image`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'QR Restaurant', 'Scan QR to pay via Esewa/Khalti', NULL, '1', '2026-07-23 19:43:19', '2026-07-23 19:43:19');

DROP TABLE IF EXISTS `tables`;
CREATE TABLE `tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_number` varchar(20) NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `table_number` (`table_number`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tables` (`id`, `table_number`, `qr_code`, `created_at`) VALUES ('1', '1', NULL, '2026-07-23 19:43:19');
INSERT INTO `tables` (`id`, `table_number`, `qr_code`, `created_at`) VALUES ('3', '3', NULL, '2026-07-23 19:43:19');
INSERT INTO `tables` (`id`, `table_number`, `qr_code`, `created_at`) VALUES ('4', '4', NULL, '2026-07-23 19:43:19');

DROP TABLE IF EXISTS `waiter_calls`;
CREATE TABLE `waiter_calls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_number` varchar(10) NOT NULL,
  `status` enum('pending','served') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `waiter_calls` (`id`, `table_number`, `status`, `created_at`) VALUES ('1', '1', 'served', '2026-07-23 19:48:46');
INSERT INTO `waiter_calls` (`id`, `table_number`, `status`, `created_at`) VALUES ('2', '1', 'served', '2026-08-07 19:37:49');

SET FOREIGN_KEY_CHECKS=1;
