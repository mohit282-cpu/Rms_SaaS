-- database/migrations/002_inventory_assets.sql - Enterprise Inventory & Asset Schema
CREATE TABLE IF NOT EXISTS inventory_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT '',
    icon VARCHAR(50) DEFAULT '📦',
    display_order INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_units (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    abbreviation VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_code VARCHAR(50) NOT NULL UNIQUE,
    company_name VARCHAR(150) NOT NULL,
    contact_person VARCHAR(100) DEFAULT '',
    email VARCHAR(100) DEFAULT '',
    phone VARCHAR(50) DEFAULT '',
    address TEXT,
    city VARCHAR(50) DEFAULT '',
    pan_vat_number VARCHAR(50) DEFAULT '',
    payment_terms VARCHAR(100) DEFAULT 'Net 30',
    status ENUM('active','inactive') DEFAULT 'active',
    rating INT DEFAULT 5,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sup_code (supplier_code),
    INDEX idx_sup_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    category_id INT DEFAULT NULL,
    supplier_id INT DEFAULT NULL,
    unit_id INT DEFAULT NULL,
    current_stock DECIMAL(12,3) DEFAULT 0.000,
    minimum_stock DECIMAL(12,3) DEFAULT 0.000,
    maximum_stock DECIMAL(12,3) DEFAULT 0.000,
    purchase_cost DECIMAL(12,2) DEFAULT 0.00,
    average_cost DECIMAL(12,2) DEFAULT 0.00,
    storage_location VARCHAR(100) DEFAULT '',
    batch_number VARCHAR(100) DEFAULT '',
    expiry_date DATE DEFAULT NULL,
    status ENUM('active','inactive','discontinued') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_inv_category (category_id),
    INDEX idx_inv_supplier (supplier_id),
    INDEX idx_inv_stock (current_stock, minimum_stock)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    menu_item_id INT NOT NULL,
    inventory_item_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    waste_percentage DECIMAL(5,2) DEFAULT 0.00,
    notes VARCHAR(255) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_recipe_menu (menu_item_id),
    INDEX idx_recipe_inv (inventory_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT NOT NULL,
    order_id INT DEFAULT NULL,
    po_id INT DEFAULT NULL,
    transaction_type ENUM('purchase','sale','waste','adjustment','transfer','return','restock') NOT NULL,
    quantity DECIMAL(12,3) NOT NULL,
    unit_cost DECIMAL(12,2) DEFAULT 0.00,
    total_cost DECIMAL(12,2) DEFAULT 0.00,
    performed_by VARCHAR(100) DEFAULT 'admin',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_trans_item (inventory_item_id),
    INDEX idx_trans_order (order_id),
    INDEX idx_trans_type (transaction_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS assets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_tag VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    category_id INT DEFAULT NULL,
    location VARCHAR(100) DEFAULT 'Main Dining',
    department VARCHAR(50) DEFAULT 'Operations',
    serial_number VARCHAR(100) DEFAULT '',
    model_number VARCHAR(100) DEFAULT '',
    purchase_date DATE DEFAULT NULL,
    purchase_cost DECIMAL(12,2) DEFAULT 0.00,
    current_value DECIMAL(12,2) DEFAULT 0.00,
    salvage_value DECIMAL(12,2) DEFAULT 0.00,
    useful_life_months INT DEFAULT 60,
    status ENUM('active','in_use','under_maintenance','damaged','retired','disposed') DEFAULT 'active',
    qr_code VARCHAR(255) DEFAULT '',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_asset_tag (asset_tag),
    INDEX idx_asset_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
