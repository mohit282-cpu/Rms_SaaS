-- database/migrations/001_initial_schema.sql - Core POS Schema
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role VARCHAR(20) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255),
    parent_id INT DEFAULT NULL,
    icon VARCHAR(50) DEFAULT '🍽️',
    image VARCHAR(255) DEFAULT '',
    display_order INT DEFAULT 0,
    status ENUM('active', 'hidden') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sku VARCHAR(50) DEFAULT '',
    category_id INT NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    cost_price DECIMAL(10, 2) DEFAULT 0.00,
    stock_quantity INT DEFAULT 50,
    min_stock_level INT DEFAULT 10,
    preparation_time INT DEFAULT 15,
    dietary_type ENUM('veg', 'non_veg', 'vegan') DEFAULT 'veg',
    allergens VARCHAR(255) DEFAULT '',
    image VARCHAR(255) DEFAULT '',
    status ENUM('active', 'sold_out', 'inactive') DEFAULT 'active',
    is_popular TINYINT(1) DEFAULT 0,
    calories INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_cat_status (category_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tables (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_number VARCHAR(20) NOT NULL UNIQUE,
    qr_code VARCHAR(255),
    qr_token VARCHAR(64) UNIQUE DEFAULT NULL,
    zone VARCHAR(50) DEFAULT 'Ground Floor',
    capacity INT DEFAULT 4,
    status ENUM('vacant', 'occupied', 'reserved', 'cleaning', 'disabled') DEFAULT 'vacant',
    assigned_waiter VARCHAR(100) DEFAULT 'Unassigned',
    reserved_by VARCHAR(100) DEFAULT '',
    guest_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dining_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_token VARCHAR(64) NOT NULL UNIQUE,
    table_number VARCHAR(20) NOT NULL,
    customer_name VARCHAR(100) DEFAULT 'Guest',
    status ENUM('active', 'payment_pending', 'completed', 'cancelled') DEFAULT 'active',
    running_total DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ds_table_status (table_number, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_number VARCHAR(20) NOT NULL,
    customer_name VARCHAR(100) DEFAULT 'Guest',
    notes TEXT,
    status ENUM('new', 'preparing', 'ready', 'completed', 'refund_requested', 'refunded', 'cancelled') DEFAULT 'new',
    total_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    payment_status ENUM('pending', 'paid', 'refunded', 'failed') DEFAULT 'pending',
    payment_method VARCHAR(50) DEFAULT 'cash',
    dining_session_id INT DEFAULT NULL,
    batch_number INT DEFAULT 1,
    idempotency_key VARCHAR(64) UNIQUE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_orders_created (created_at),
    INDEX idx_orders_status_pay (status, payment_status),
    INDEX idx_orders_table_status (table_number, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_item_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE,
    INDEX idx_oi_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
