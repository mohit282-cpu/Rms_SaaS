# ☕ QR Cafe — Restaurant Management System (RMS)

<div align="center">

![Version](https://img.shields.io/badge/version-2.0.0--Pro-amber?style=for-the-badge&logo=coffee)
![PHP](https://img.shields.io/badge/PHP-8.1+-777BB4?style=for-the-badge&logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-8.0+-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-v3.4-38BDF8?style=for-the-badge&logo=tailwind-css&logoColor=white)
![PWA](https://img.shields.io/badge/PWA-Ready-10B981?style=for-the-badge&logo=pwa&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-F59E0B?style=for-the-badge)

**A modern, mobile-first, full-stack Restaurant Management & Table QR Digital Ordering System.**

[System Overview](#-system-overview--ecosystem) • [System Architecture](#-complete-system-architecture) • [Customer Flow](#-customer-ordering-sequence) • [Kitchen Flow](#-kitchen-fulfillment-sequence) • [Order Lifecycle](#-order-lifecycle-state-machine) • [Database ERD](#-database-entity-relationship-erd) • [Admin Customizer](#-admin-management--landing-customizer-workflow) • [Security Flow](#-security--hmac-url-signature-flow) • [Directory Map](#-visual-file--directory-map) • [Setup Guide](#-visual-installation--setup-flow)

</div>

---

## 🌐 System Overview & Ecosystem

```mermaid
graph LR
    subgraph ACTORS ["👥 System Roles"]
        Customer["📱 Dining Customer"]
        Kitchen["👨‍🍳 Kitchen Staff"]
        Admin["📊 Restaurant Manager"]
    end

    subgraph SYSTEM ["☕ QR Cafe System Ecosystem"]
        direction TB
        CustomerPortal["📱 Digital Menu & Order Tracker<br/>(Mobile PWA)"]
        KDS["👨‍🍳 Kitchen Display System<br/>(Realtime KDS & Sound Alerts)"]
        AdminConsole["📊 Manager Admin Console<br/>(Analytics, Inventory & Customizer)"]
        Database[("💾 MySQL Database<br/>(Auto Schema Migration)")]
    end

    Customer -->|"Scans Table QR & Orders"| CustomerPortal
    CustomerPortal -->|"Inserts Order"| Database
    Database -->|"Polls Active Orders"| KDS
    Kitchen -->|"Updates Status (Preparing/Ready)"| KDS
    KDS -->|"Saves State"| Database
    Database -->|"Realtime Status Updates"| CustomerPortal
    Admin -->|"Manages Menu, Tables & Content"| AdminConsole
    AdminConsole -->|"Configures Settings"| Database

    classDef actor fill:#166534,stroke:#22c55e,stroke-width:2px,color:#fff;
    classDef portal fill:#0f172a,stroke:#f59e0b,stroke-width:2px,color:#fff;
    classDef db fill:#0284c7,stroke:#38bdf8,stroke-width:2px,color:#fff;

    class Customer,Kitchen,Admin actor;
    class CustomerPortal,KDS,AdminConsole portal;
    class Database db;
```

---

## 🏗️ Complete System Architecture

```mermaid
graph TB
    subgraph FRONTEND ["📱 Customer Portal (Public & Mobile PWA)"]
        IndexPage["index.php<br/>(Restaurant Landing Page)"]
        QRScan["QR Code Scan<br/>(Signed URL)"]
        MenuPage["menu.php<br/>(Digital Menu & Addons Modal)"]
        CartPage["cart.php<br/>(Order Review Drawer)"]
        CheckoutPage["checkout.php<br/>(Place Order)"]
        SuccessPage["order-success.php<br/>(Realtime Order Tracker)"]
    end

    subgraph KITCHEN ["👨‍🍳 Kitchen Display System (KDS)"]
        KDSLock["KDS Password Lock<br/>(requireKitchenLogin)"]
        KDSMonitor["kitchen-dashboard.php<br/>(Live Order Stream & Sound Alert)"]
        KDSStock["kitchen-menu.php<br/>(Quick Stock Toggle)"]
    end

    subgraph ADMIN ["📊 Manager Admin Console (/admin/)"]
        AdminLogin["login.php<br/>(Admin Authentication)"]
        Dashboard["index.php<br/>(Sales Analytics & Summary)"]
        LandingEditor["landing-page.php<br/>(Tabbed Editor + Live Hero Preview)"]
        OrdersManager["orders.php & order-details.php<br/>(Live Queue & Bill Details)"]
        MenuManager["menu-items.php & categories.php<br/>(Inventory & Addons)"]
        TableManager["tables.php<br/>(Seating & Printable QR Generator)"]
        PaymentManager["payment-settings.php<br/>(eSewa / Khalti QR Config)"]
    end

    subgraph API_LAYER ["⚡ Realtime AJAX API Layer (/api/)"]
        API_Status["api/get-order-status.php"]
        API_Update["api/update-order.php"]
        API_Orders["api/orders.php"]
        API_Stock["api/toggle-stock.php"]
        API_Waiter["api/call-waiter.php"]
    end

    subgraph DB ["💾 Database Layer (MySQL)"]
        MySQL[("qr_restaurant Database<br/>(ensureDatabaseSchema)")]
    end

    %% Customer Connections
    IndexPage --> QRScan
    QRScan --> MenuPage
    MenuPage --> CartPage
    CartPage --> CheckoutPage
    CheckoutPage -->|"POST /place-order.php"| MySQL
    CheckoutPage --> SuccessPage
    SuccessPage -- "AJAX Poll (3s)" --> API_Status
    API_Status --> MySQL
    SuccessPage -- "Tap Button" --> API_Waiter
    API_Waiter --> MySQL

    %% Kitchen Connections
    KDSLock --> KDSMonitor
    KDSMonitor -- "AJAX Poll (5s)" --> API_Orders
    API_Orders --> MySQL
    KDSMonitor -- "Status Change" --> API_Update
    API_Update --> MySQL
    KDSStock -- "Toggle In/Out Stock" --> API_Stock
    API_Stock --> MySQL

    %% Admin Connections
    AdminLogin --> Dashboard
    Dashboard --> OrdersManager
    Dashboard --> MenuManager
    Dashboard --> TableManager
    Dashboard --> LandingEditor
    Dashboard --> PaymentManager
    OrdersManager --> MySQL
    MenuManager --> MySQL
    TableManager --> MySQL
    LandingEditor --> MySQL
    PaymentManager --> MySQL

    classDef customer fill:#0284c7,stroke:#38bdf8,stroke-width:2px,color:#fff;
    classDef kitchen fill:#d97706,stroke:#f59e0b,stroke-width:2px,color:#fff;
    classDef admin fill:#4c1d95,stroke:#a855f7,stroke-width:2px,color:#fff;
    classDef api fill:#065f46,stroke:#34d399,stroke-width:2px,color:#fff;
    classDef db fill:#1e293b,stroke:#94a3b8,stroke-width:2px,color:#fff;

    class IndexPage,QRScan,MenuPage,CartPage,CheckoutPage,SuccessPage customer;
    class KDSLock,KDSMonitor,KDSStock kitchen;
    class AdminLogin,Dashboard,LandingEditor,OrdersManager,MenuManager,TableManager,PaymentManager admin;
    class API_Status,API_Update,API_Orders,API_Stock,API_Waiter api;
    class MySQL db;
```

---

## 🔄 Customer Ordering Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Customer as 📱 Customer
    participant Menu as menu.php
    participant Cart as cart.php / checkout.php
    participant Handler as place-order.php
    participant DB as 💾 MySQL Database
    participant KDS as 👨‍🍳 KDS Monitor
    participant Tracker as order-success.php

    Customer->>Menu: 1. Scans Table QR Code (menu.php?table=4&sig=...)
    Note over Menu: Validates HMAC-SHA256 Signature
    Menu-->>Customer: 2. Displays Digital Menu (Categories, Veg/Non-Veg, Addons)
    Customer->>Cart: 3. Selects Items, Addons & Quantities
    Cart-->>Customer: 4. Reviews Cart & Enters Name / Notes
    Customer->>Handler: 5. Submits Order (POST)
    Handler->>DB: 6. Saves Order & Order Items (Status: 'new')
    DB-->>Handler: 7. Returns New Order ID (#104)
    Handler-->>Customer: 8. Redirects to order-success.php?id=104

    par Realtime Synchronization
        loop Every 5 seconds
            KDS->>DB: Poll active orders via /api/orders.php
            DB-->>KDS: Return Order #104 ('new')
            Note over KDS: Triggers Audio Notification Bell 🔔
        end
        loop Every 3 seconds
            Tracker->>DB: Poll status via /api/get-order-status.php
            DB-->>Tracker: Return Status: 'new'
            Tracker-->>Customer: Updates Progress Bar UI ('Order Received')
        end
    end
```

---

## 👨‍🍳 Kitchen Fulfillment Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Chef as 👨‍🍳 Kitchen Staff
    participant KDS as kitchen-dashboard.php
    participant API as /api/update-order.php
    participant DB as 💾 MySQL Database
    actor Customer as 📱 Customer Tracker

    Chef->>KDS: 1. Opens KDS & Enters Kitchen Password ('kitchen123')
    Note over KDS: Authenticates Session (requireKitchenLogin)
    
    loop Realtime Order Monitoring
        KDS->>DB: 2. Polls active orders (status: new, preparing, ready)
        DB-->>KDS: 3. Returns Order #104 (Table #4, 2x Burger, 1x Espresso)
        Note over KDS: Displays Orange Card & Plays Audio Sound 🔔
    end

    Chef->>KDS: 4. Clicks "Start Preparing"
    KDS->>API: 5. Sends POST { id: 104, status: 'preparing' }
    API->>DB: 6. Updates order status to 'preparing'
    
    Note over Customer: Progress Bar advances to "In Kitchen 👨‍🍳"

    Chef->>KDS: 7. Clicks "Mark Ready"
    KDS->>API: 8. Sends POST { id: 104, status: 'ready' }
    API->>DB: 9. Updates order status to 'ready'
    
    Note over Customer: Progress Bar advances to "Ready for Pickup/Serving 🍽️"

    Chef->>KDS: 10. Clicks "Served & Complete"
    KDS->>API: 11. Sends POST { id: 104, status: 'completed' }
    API->>DB: 12. Updates order status to 'completed'
```

---

## 🚦 Order Lifecycle State Machine

```mermaid
stateDiagram-v2
    [*] --> New : Customer Places Order via checkout.php
    
    state New {
        [*] --> OrderReceived
        OrderReceived --> SoundAlertTriggered : KDS Polling (5s)
    }
    
    New --> Preparing : Kitchen Clicks "Start Preparing"
    
    state Preparing {
        [*] --> InKitchenCooking
        InKitchenCooking --> ElapsedTimerActive : Tracks Prep Time
    }
    
    Preparing --> Ready : Kitchen Clicks "Mark Ready"
    
    state Ready {
        [*] --> ReadyForTableDelivery
        ReadyForTableDelivery --> WaiterNotified
    }
    
    Ready --> Completed : Staff Clicks "Served & Complete"
    New --> Cancelled : Staff / Admin Clicks "Cancel Order"
    Preparing --> Cancelled : Admin Clicks "Cancel Order"

    Completed --> [*] : Bill Settled (Cash or eSewa/Khalti QR)
    Cancelled --> [*]
```

---

## 🗄️ Database Entity Relationship (ERD)

```mermaid
erDiagram
    landing_page_settings {
        int id PK
        string brand_name
        string brand_logo
        string brand_logo_image
        string hero_badge
        string hero_title
        text hero_subtitle
        string hero_cta_primary
        string hero_cta_secondary
        string qr_notice_text
        string about_badge
        string about_title
        text about_text
        string about_feature1_title
        string about_feature1_desc
        string about_feature2_title
        string about_feature2_desc
        string dishes_badge
        string dishes_title
        string dishes_subtitle
        string location_title
        string location_address
        string contact_phone
        string contact_email
        string hours_title
        string opening_hours
        string hero_image
        string footer_copyright
        string kds_password
    }

    admin_users {
        int id PK
        string username UK
        string password
        string full_name
        timestamp created_at
    }

    categories {
        int id PK
        string name UK
        string description
        timestamp created_at
    }

    menu_items {
        int id PK
        string name
        text description
        decimal price
        string image
        int category_id FK
        enum status "'active','sold_out','inactive'"
        tinyint is_popular
        int preparation_time
        enum dietary_type "'veg','non-veg'"
        text addons
        timestamp created_at
    }

    menu_addons {
        int id PK
        string name
        decimal price
        enum status "'active','inactive'"
        timestamp created_at
    }

    tables {
        int id PK
        string table_number UK
        string qr_code
        timestamp created_at
    }

    orders {
        int id PK
        string table_number
        string customer_name
        text notes
        enum status "'new','preparing','ready','completed','cancelled'"
        decimal total_amount
        enum payment_status "'pending','paid'"
        string payment_method
        timestamp created_at
        timestamp updated_at
    }

    order_items {
        int id PK
        int order_id FK
        int menu_item_id FK
        int quantity
        decimal price
    }

    payment_settings {
        int id PK
        string restaurant_name
        string payment_note
        string qr_code_image
        tinyint is_active
        timestamp created_at
    }

    waiter_calls {
        int id PK
        string table_number
        enum status "'pending','served'"
        timestamp created_at
    }

    categories ||--|{ menu_items : "contains (1 to N)"
    orders ||--|{ order_items : "contains (1 to N)"
    menu_items ||--|{ order_items : "referenced in (1 to N)"
```

---

## 📊 Admin Management & Landing Customizer Workflow

```mermaid
flowchart TD
    subgraph AUTH ["🔒 Admin Authentication"]
        A1["Access /admin/"] --> A2{"Is Admin Logged In?"}
        A2 -- No --> A3["Show Login Form (login.php)"]
        A3 --> A4["Submit Credentials (login-process.php)"]
        A4 -- Valid --> A5["Set Session & Grant Access"]
        A2 -- Yes --> A5
    end

    subgraph CONSOLE ["📊 Admin Console Modules"]
        A5 --> B1["Dashboard Analytics Summary (admin/index.php)"]
        A5 --> B2["Landing Page Editor (admin/landing-page.php)"]
        A5 --> B3["Live Orders Queue (admin/orders.php)"]
        A5 --> B4["Menu Inventory Manager (admin/menu-items.php)"]
        A5 --> B5["Table & QR Generator (admin/tables.php)"]
        A5 --> B6["Payment Settings (admin/payment-settings.php)"]
    end

    subgraph LANDING_TABS ["🌐 6-Tab Landing Content Editor"]
        B2 --> T1["🏷️ Branding & Logo<br/>(Name, Emoji, Custom Logo Upload)"]
        B2 --> T2["⭐ Hero Banner<br/>(Headline, CTAs, Live Hero Preview)"]
        B2 --> T3["📖 Story & About<br/>(Badges, Stats, Showcase Photo)"]
        B2 --> T4["🍽️ Dishes Section<br/>(Headers & Subtitles)"]
        B2 --> T5["📍 Contact & Hours<br/>(Location, Phone, Schedule)"]
        B2 --> T6["📄 Footer & Legal<br/>(Copyright & Links)"]
    end

    subgraph DB_UPDATE ["💾 Database Update"]
        T1 & T2 & T3 & T4 & T5 & T6 --> S1["Click 'Save All Settings'"]
        S1 --> S2["UPDATE landing_page_settings in MySQL"]
        S2 --> S3["Instant Update on Customer Landing Page (index.php)"]
    end

    classDef auth fill:#1e293b,stroke:#64748b,stroke-width:2px,color:#fff;
    classDef console fill:#4c1d95,stroke:#c084fc,stroke-width:2px,color:#fff;
    classDef tab fill:#065f46,stroke:#34d399,stroke-width:2px,color:#fff;
    classDef db fill:#b45309,stroke:#fbbf24,stroke-width:2px,color:#fff;

    class A1,A2,A3,A4,A5 auth;
    class B1,B2,B3,B4,B5,B6 console;
    class T1,T2,T3,T4,T5,T6 tab;
    class S1,S2,S3 db;
```

---

## 🔒 Security & HMAC URL Signature Flow

```mermaid
flowchart LR
    subgraph GENERATION ["⚙️ Admin Table QR Generation"]
        T1["Admin Adds Table #4"] --> T2["generateSignedTableUrl('4')"]
        T2 --> T3["Compute HMAC-SHA256('table_4', QR_SECRET_KEY)"]
        T3 --> T4["Generate URL: menu.php?table=4&sig=a8f9b2..."]
        T4 --> T5["Print Table QR Card"]
    end

    subgraph VERIFICATION ["🛡️ Customer Request Verification"]
        C1["Customer Scans QR Code"] --> C2["Request menu.php?table=4&sig=a8f9b2..."]
        C2 --> C3["verifyTableSignature('4', 'a8f9b2...')"]
        C3 --> C4{"Does Computed HMAC Match Received Signature?"}
        C4 -- Yes --> C5["Allow Access & Bind Session to Table #4"]
        C4 -- No --> C6["Deny Access / Show Security Warning"]
    end

    classDef gen fill:#0f172a,stroke:#38bdf8,stroke-width:2px,color:#fff;
    classDef ver fill:#14532d,stroke:#4ade80,stroke-width:2px,color:#fff;

    class T1,T2,T3,T4,T5 gen;
    class C1,C2,C3,C4,C5,C6 ver;
```

---

## 📁 Visual File & Directory Map

```
z:/Xampp/htdocs/RMS_System/
│
├── 📜 config.php                ──► Database connection, HMAC URL signing & auto-schema migration
├── 📜 index.php                 ──► Public Restaurant Landing Page (dynamic customizer data)
├── 📜 menu.php                  ──► Table-Signed Digital Menu (Search, Categories, Addons modal)
├── 📜 cart.php                  ──► Cart Drawer & Order Review
├── 📜 checkout.php              ──► Order Submission & HMAC Table Verification
├── 📜 place-order.php           ──► Backend Handler for customer order submission
├── 📜 order-success.php         ──► Real-time Customer Order Status Tracker & Payment Info
├── 📜 kitchen-dashboard.php     ──► Real-time Kitchen Display System (KDS) with sound alerts
├── 📜 kitchen-menu.php          ──► Quick Kitchen Stock Availability Toggle Screen
├── 📜 database.sql              ──► Complete SQL Database Dump Schema
├── 📜 manifest.json             ──► Progressive Web App (PWA) Manifest
├── 📜 .htaccess                 ──► Apache rewrite rules & security headers
│
├── 📂 admin/                    ──► 📊 Manager Console Portal
│   ├── 📜 index.php             ──► Analytics Summary Dashboard & Quick Stock Control
│   ├── 📜 landing-page.php      ──► Tabbed Landing Page Content Editor + Live Hero Preview
│   ├── 📜 orders.php            ──► Live Orders Queue & Status Filter
│   ├── 📜 order-details.php     ──► Detailed Order Bill & Item Breakdown
│   ├── 📜 menu-items.php        ──► Inventory Manager (CRUD, Images, Addons, Stock status)
│   ├── 📜 categories.php        ──► Category CRUD Manager
│   ├── 📜 tables.php            ──► Seating Tables Manager & Printable QR Generator
│   ├── 📜 payment-settings.php  ──► Digital Payment QR Code Configurator (eSewa / Khalti)
│   ├── 📜 change-password.php   ──► Admin & KDS Password Management
│   ├── 📜 login.php             ──► Admin Login Page
│   ├── 📜 login-process.php     ──► Authentication logic
│   └── 📜 logout.php            ──► Session logout handler
│
├── 📂 api/                      ──► ⚡ Asynchronous AJAX Endpoints
│   ├── 📜 call-waiter.php       ──► Table waiter call alert handler
│   ├── 📜 get-order-status.php  ──► Realtime polling endpoint for customer tracker
│   ├── 📜 update-order.php      ──► Status updater for Kitchen & Admin
│   ├── 📜 toggle-stock.php      ──► Instant In-Stock / Out-of-Stock toggle
│   ├── 📜 orders.php            ──► Active orders fetch API for KDS
│   ├── 📜 payment-settings.php  ──► Payment QR details API
│   ├── 📜 menu.php              ──► JSON menu fetch API
│   └── 📜 menu-status.php       ──► Stock status check API
│
├── 📂 images/                   ──► Uploaded brand logos, hero photos, food items & QR codes
├── 📂 css/                      ──► Tailored stylesheets & utilities
└── 📂 js/                       ──► Modern JavaScript modules & sound handlers
```

---

## ⚡ Asynchronous API Matrix

| API Endpoint | HTTP Method | Target Component | Purpose & Description |
| :--- | :---: | :--- | :--- |
| `/api/get-order-status.php` | `GET` | Customer Order Tracker | Returns JSON status (`new`, `preparing`, `ready`, `completed`) for order progress bar. |
| `/api/orders.php` | `GET` | Kitchen KDS Monitor | Fetches active unserved orders for real-time KDS stream rendering. |
| `/api/update-order.php` | `POST` | KDS & Admin Orders | Updates order lifecycle status in MySQL database. |
| `/api/toggle-stock.php` | `POST` | Quick Stock Toggles | Toggles menu item availability (`active` ↔ `sold_out`) instantly without page reload. |
| `/api/call-waiter.php` | `POST` | Customer Tracker | Logs waiter assistance call for specified table number. |
| `/api/payment-settings.php` | `GET` | Customer Bill Tracker | Retrieves active digital payment QR code images and payment instructions. |

---

## 💻 Visual Installation & Setup Flow

```mermaid
flowchart TD
    S1["1. Copy RMS_System to htdocs / www"] --> S2["2. Verify config.php Database Credentials"]
    S2 --> S3["3. Open http://localhost/RMS_System/ in Browser"]
    S3 --> S4["4. Automatic DB & Schema Migration Runs (ensureDatabaseSchema)"]
    S4 --> S5["5. System Ready for Use!"]

    S5 --> S6["🛡️ Admin Login:<br/>http://localhost/RMS_System/admin/<br/>(admin / admin123)"]
    S5 --> S7["👨‍🍳 Kitchen KDS:<br/>http://localhost/RMS_System/kitchen-dashboard.php<br/>(Pass: kitchen123)"]
    S5 --> S8["📱 Customer Demo:<br/>http://localhost/RMS_System/menu.php?table=1"]

    classDef step fill:#0f172a,stroke:#38bdf8,stroke-width:2px,color:#fff;
    classDef portal fill:#166534,stroke:#4ade80,stroke-width:2px,color:#fff;

    class S1,S2,S3,S4,S5 step;
    class S6,S7,S8 portal;
```

---

## 🎨 UI/UX Design Token Specifications

```
  BACKGROUND           SURFACE CARDS        PRIMARY ACCENTS       DIETARY BADGES
  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
  │  zinc-950    │     │  zinc-900    │     │  amber-500   │     │ Veg:   🟢    │
  │  #09090b     │     │  #18181b     │     │  #f59e0b     │     │ Non-Veg: 🔴  │
  └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
```

---

<div align="center">

**Developed with ❤️ for Modern Dining Experiences**  
© 2026 QR Cafe · Powered by **Sovryx Tech Pvt. Ltd.**

</div>
